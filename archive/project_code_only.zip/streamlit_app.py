import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
import numpy as np
from io import BytesIO

# ---------- 1. Page Configuration ----------
st.set_page_config(
    page_title="PV LCA Decision Engine",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- CSS STYLING ---
st.markdown("""
<style>
    .block-container { padding-top: 1rem; }
    div[data-testid="stMetric"] {
        background-color: var(--secondary-background-color);
        border: 1px solid rgba(128, 128, 128, 0.2);
        border-radius: 8px;
        padding: 10px;
    }
    .recommendation-box {
        border-left: 5px solid #27ae60;
        background-color: rgba(39, 174, 96, 0.1);
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }
</style>
""", unsafe_allow_html=True)

# ---------- 2. Data Loading & Logic ----------
WB = "data/EPD_Hub_V3_PV_master_curated_v1.xlsx"
TARGET_SHEET = "INDICATORS_NORMALIZED"
REQUIRED_COLUMNS = ['manufacturer', 'name', 'module_power_Wp', 'module_area_m2', 'GWP_total_A1A3_per_kWp_kgCO2e']

def process_dataframe(df):
    """Runs the Engineering Physics calculations on any dataframe (imported or master)."""
    for col in ['module_power_Wp', 'module_area_m2', 'GWP_total_A1A3_per_kWp_kgCO2e']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    if 'manufacturer' in df.columns and 'name' in df.columns:
        df['Display_Name'] = df.apply(lambda x: f"{x['manufacturer']} - {str(x['name'])[:25]}", axis=1)
    
    if 'module_power_Wp' in df.columns and 'module_area_m2' in df.columns:
        df['Efficiency_Pct'] = (df['module_power_Wp'] / (df['module_area_m2'] * 1000)) * 100
    else:
        df['Efficiency_Pct'] = 0

    def calculate_uncertainty(row):
        score_rel = 1 if (pd.notna(row.get('source')) and '.pdf' in str(row['source']).lower()) else 3
        score_comp = 1 if (pd.notna(row.get('module_power_Wp')) and row['module_power_Wp'] > 0) else 4
        score_temp = 1 if (pd.notna(row.get('version'))) else 3
        uncertainty_factor = 0.05 + (0.02 * (score_rel - 1)) + (0.02 * (score_comp - 1)) + (0.02 * (score_temp - 1))
        return uncertainty_factor 

    df['Uncertainty_SD'] = df.apply(calculate_uncertainty, axis=1)
    return df

@st.cache_data
def load_master_data():
    try:
        xl = pd.ExcelFile(WB)
        sheet_names = xl.sheet_names
        load_sheet = TARGET_SHEET if TARGET_SHEET in sheet_names else sheet_names[0]
        df = pd.read_excel(WB, sheet_name=load_sheet)
        return process_dataframe(df)
    except Exception as e:
        st.error(f"Critical Data Error: {e}")
        return pd.DataFrame()

df_master = load_master_data()

# ---------- 3. Sidebar: Data Import ----------
st.sidebar.title("📂 Data Manager")

with st.sidebar.expander("➕ Import Project Database", expanded=False):
    # --- HELPER TEXT (The 'Smart' Explanation) ---
    st.info(
        """
        **How to Import:**
        1. Download the **Blank Template** below.
        2. Fill in the 5 mandatory columns:
           - `manufacturer` & `name` (Text)
           - `module_power_Wp` (e.g., 450)
           - `module_area_m2` (e.g., 2.1)
           - `GWP_total_A1A3_per_kWp_kgCO2e` (e.g., 450.5)
        3. Upload the CSV back here.
        
        *Note: The engine will automatically calculate Efficiency & Uncertainty for you.*
        """
    )

    # A. Download Template
    template_df = pd.DataFrame(columns=REQUIRED_COLUMNS)
    csv_template = template_df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download Blank Template (CSV)",
        data=csv_template,
        file_name="module_import_template.csv",
        mime="text/csv"
    )
    
    # B. Upload File
    uploaded_file = st.file_uploader("Upload Filled CSV", type=["csv"])
    
    if uploaded_file is not None:
        try:
            df_new = pd.read_csv(uploaded_file)
            missing = [c for c in REQUIRED_COLUMNS if c not in df_new.columns]
            if missing:
                st.error(f"Missing mandatory columns: {missing}")
            else:
                df_new['source'] = "Custom Import"
                df_new = process_dataframe(df_new)
                df_master = pd.concat([df_new, df_master], ignore_index=True)
                st.success(f"✅ Loaded {len(df_new)} custom modules!")
        except Exception as e:
            st.error(f"Import Failed: {e}")

# ---------- 4. Sidebar: Project Scenarios ----------
st.sidebar.divider()
st.sidebar.subheader("🏗️ Optimization Setup")

location_presets = {
    "Custom (Manual Input)": {"yield": 1000, "temp": 10.0, "grid": 400},
    "🇩🇪 Germany (Berlin)": {"yield": 1050, "temp": 5.0, "grid": 380},
    "🇪🇸 Spain (Seville)": {"yield": 1750, "temp": 14.0, "grid": 190},
    "🇺🇸 USA (Arizona)": {"yield": 1900, "temp": 16.0, "grid": 350},
    "🇨🇳 China (Shanghai)": {"yield": 1100, "temp": 8.0, "grid": 550},
    "🇸🇪 Sweden (Stockholm)": {"yield": 950, "temp": 2.0, "grid": 40},
}
selected_loc = st.sidebar.selectbox("📍 Select Project Location", list(location_presets.keys()))
defaults = location_presets[selected_loc]

scenario = st.sidebar.selectbox(
    "Optimization Goal",
    ["Eco-Flagship (Minimize Carbon)", "Utility Scale (Lowest LCOE)", "Space Constrained (Rooftop)"],
    index=0
)

with st.sidebar.expander("⚙️ Technical Specs", expanded=False):
    base_irradiance = st.number_input("Specific Yield (kWh/kWp/yr)", min_value=500, max_value=2600, value=defaults["yield"])
    lifetime = st.slider("Project Lifetime (Years)", 10, 40, 30)
    temp_loss = st.slider("Temp. Loss Factor (%)", 0.0, 25.0, defaults["temp"])

with st.sidebar.expander("💰 Market Assumptions", expanded=False):
    avg_price_wp = st.number_input("Avg. Module Price (€/Wp)", 0.08, 1.50, 0.22, 0.01)
    bos_cost_wp = st.number_input("BOS Cost (€/Wp)", 0.20, 3.00, 0.45)
    opex_annual = st.number_input("O&M Cost (€/kWp/yr)", 2.0, 100.0, 15.0)

# Filter
if 'manufacturer' in df_master.columns:
    manufacturers = sorted(df_master['manufacturer'].dropna().astype(str).unique())
    selected_mfg = st.sidebar.multiselect("Filter Brand", manufacturers)
else:
    selected_mfg = []

# ---------- 5. Calculation Engine ----------
df_calc = df_master.copy()
if selected_mfg:
    df_calc = df_calc[df_calc['manufacturer'].astype(str).isin(selected_mfg)]

df_calc = df_calc.dropna(subset=['GWP_total_A1A3_per_kWp_kgCO2e'])

effective_yield = base_irradiance * (1 - (temp_loss/100))
df_calc['Carbon_Intensity_Mean'] = (df_calc['GWP_total_A1A3_per_kWp_kgCO2e'] * 1000) / (effective_yield * lifetime)
df_calc['Estimated_Price_Wp'] = avg_price_wp * (1 + (df_calc['Efficiency_Pct'] - 20)/100)
capex = (df_calc['Estimated_Price_Wp'] + bos_cost_wp) * 1000
opex = opex_annual * lifetime
production = effective_yield * lifetime
df_calc['LCOE_EUR_MWh'] = ((capex + opex) / production) * 1000

def normalize(series, invert=False):
    min_val = series.min()
    max_val = series.max()
    if max_val == min_val: return 1.0
    norm = (series - min_val) / (max_val - min_val)
    return 1 - norm if invert else norm

df_calc['Score_Eco'] = normalize(df_calc['Carbon_Intensity_Mean'], invert=True)
df_calc['Score_Cost'] = normalize(df_calc['LCOE_EUR_MWh'], invert=True)
df_calc['Score_Tech'] = normalize(df_calc['Efficiency_Pct'], invert=False)

if scenario == "Eco-Flagship (Minimize Carbon)":
    w_eco, w_cost, w_tech = 0.70, 0.15, 0.15
elif scenario == "Utility Scale (Lowest LCOE)":
    w_eco, w_cost, w_tech = 0.20, 0.60, 0.20
else:
    w_eco, w_cost, w_tech = 0.20, 0.20, 0.60

df_calc['Suitability_Index'] = (
    (df_calc['Score_Eco'] * w_eco) + 
    (df_calc['Score_Cost'] * w_cost) + 
    (df_calc['Score_Tech'] * w_tech)
) * 100

df_calc = df_calc.sort_values('Suitability_Index', ascending=False)
winner = df_calc.iloc[0]

# ---------- 6. Dashboard ----------
st.title(f"PV LCA Optimization Engine v2.4")

if 'Custom Import' in df_calc['source'].values:
    st.info("ℹ️ Displaying results including imported custom data.")

st.markdown(f"""
<div class="recommendation-box">
    <h3>🏆 Optimal Choice: {winner['manufacturer']} {str(winner['name'])[:20]}...</h3>
    <p>Based on the <b>{selected_loc}</b> location profile and <b>{scenario}</b> strategy.</p>
    <ul>
        <li><b>Suitability Index:</b> {winner['Suitability_Index']:.1f}/100</li>
        <li><b>Est. LCOE:</b> {winner['LCOE_EUR_MWh']:.2f} €/MWh</li>
        <li><b>Carbon Intensity:</b> {winner['Carbon_Intensity_Mean']:.1f} gCO2e/kWh</li>
    </ul>
</div>
""", unsafe_allow_html=True)

tab1, tab2, tab3 = st.tabs(["🕸️ MCDA Analysis", "📊 Stochastic Risk", "💾 Raw Data"])

with tab1:
    c1, c2 = st.columns([2, 1])
    with c1:
        st.subheader("Trade-off Topology")
        categories = ['Low Carbon', 'Low Cost (LCOE)', 'High Efficiency']
        fig_radar = go.Figure()
        fig_radar.add_trace(go.Scatterpolar(
            r=[winner['Score_Eco'], winner['Score_Cost'], winner['Score_Tech']],
            theta=categories, fill='toself', name=f"Winner"
        ))
        fig_radar.add_trace(go.Scatterpolar(
            r=[df_calc['Score_Eco'].mean(), df_calc['Score_Cost'].mean(), df_calc['Score_Tech'].mean()],
            theta=categories, name='Market Avg', line=dict(color='gray', dash='dot')
        ))
        fig_radar.update_layout(polar=dict(radialaxis=dict(visible=True, range=[0, 1])), showlegend=True)
        st.plotly_chart(fig_radar, use_container_width=True)
    with c2:
        st.markdown("**Optimization Weights:**")
        st.progress(w_eco, text=f"Environmental: {int(w_eco*100)}%")
        st.progress(w_cost, text=f"Economic: {int(w_cost*100)}%")
        st.progress(w_tech, text=f"Technical: {int(w_tech*100)}%")

with tab2:
    st.subheader("Risk Analysis (Monte Carlo N=1000)")
    top_3 = df_calc.head(3)
    n_sims = 1000
    sim_data = []
    for i, row in top_3.iterrows():
        mean_gwp = row['GWP_total_A1A3_per_kWp_kgCO2e']
        sigma = row['Uncertainty_SD']
        mu = np.log(mean_gwp) - 0.5 * sigma**2
        samples_gwp = np.random.lognormal(mu, sigma, n_sims)
        samples_intensity = (samples_gwp * 1000) / (effective_yield * lifetime)
        for x in samples_intensity:
            sim_data.append({'Module': row['manufacturer'], 'Intensity (g/kWh)': x})
    df_sim = pd.DataFrame(sim_data)
    fig_mc = px.histogram(df_sim, x="Intensity (g/kWh)", color="Module", barmode="overlay", nbins=50, opacity=0.7)
    st.plotly_chart(fig_mc, use_container_width=True)

with tab3:
    cols = ['manufacturer', 'name', 'Suitability_Index', 'Carbon_Intensity_Mean', 'LCOE_EUR_MWh', 'Efficiency_Pct', 'source']
    st.dataframe(df_calc[cols].style.background_gradient(subset=['Suitability_Index'], cmap='Greens'), use_container_width=True)